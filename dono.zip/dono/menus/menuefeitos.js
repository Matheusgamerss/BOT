const menuefeitos = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split('@')[0]}

『 𝐌𝐄𝐍𝐔✰𝐄𝐅𝐄𝐈𝐓𝐎𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🧩 ${prefix}cartoon
 | ೈ፝͜͡🧩 ${prefix}toanime
 | ೈ፝͜͡🧩 ${prefix}tozombie
 | ೈ፝͜͡🧩 ${prefix}remini
 | ೈ፝͜͡🧩 ${prefix}affect
 | ೈ፝͜͡🧩 ${prefix}comunismo
 | ೈ፝͜͡🧩 ${prefix}mms
 | ೈ፝͜͡🧩 ${prefix}bobross
 | ೈ፝͜͡🧩 ${prefix}bolsonaro
 | ೈ፝͜͡🧩 ${prefix}blur
 | ೈ፝͜͡🧩 ${prefix}beautiful
 | ೈ፝͜͡🧩 ${prefix}circle
 | ೈ፝͜͡🧩 ${prefix}del
 | ೈ፝͜͡🧩 ${prefix}invert
 | ೈ፝͜͡🧩 ${prefix}facepalm
 | ೈ፝͜͡🧩 ${prefix}rip
 | ೈ፝͜͡🧩 ${prefix}wasted
 | ೈ፝͜͡🧩 ${prefix}wanted
 | ೈ፝͜͡🧩 ${prefix}trash
 | ೈ፝͜͡🧩 ${prefix}sepia
 | ೈ፝͜͡🧩 ${prefix}pixelate
 | ೈ፝͜͡🧩 ${prefix}lgbt
╰════════════════════╮`
}

exports.menuefeitos = menuefeitos