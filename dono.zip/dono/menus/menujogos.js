const menujogos = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐉𝐎𝐆𝐎𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🎮 ${prefix}jogodavelha @
 | ೈ፝͜͡🎮 ${prefix}rv
 | ೈ፝͜͡🎮 ${prefix}akinator
 | ೈ፝͜͡🎮 ${prefix}resetaki
 | ೈ፝͜͡🎮 ${prefix}anagrama
 | ೈ፝͜͡🎮 ${prefix}revelaranagrama
 | ೈ፝͜͡🎮 ${prefix}quizanimais
 | ೈ፝͜͡🎮 ${prefix}revelarquiz
 | ೈ፝͜͡🎮 ${prefix}eununca
 | ೈ፝͜͡🎮 ${prefix}vdddsf
 | ೈ፝͜͡🎮 ${prefix}forca
 | ೈ፝͜͡🎮 ${prefix}rfc
 | ೈ፝͜͡🎮 ${prefix}campominado @
 | ೈ፝͜͡🎮 ${prefix}resetmina
 | ೈ፝͜͡🎮 ${prefix}cassino
 | ೈ፝͜͡🎮 ${prefix}ppt
 | ೈ፝͜͡🎮 ${prefix}dado
 | ೈ፝͜͡🎮 ${prefix}caraoucoroa
 | ೈ፝͜͡🎮 ${prefix}adivinharnmr
╰════════════════════╮`
}

exports.menujogos = menujogos