const menuzoeira = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐙𝐎𝐄𝐈𝐑𝐀 』
╭════════════════════╯
 | ೈ፝͜͡🤪 ${prefix}beijo @
 | ೈ፝͜͡🤪 ${prefix}tapa @
 | ೈ፝͜͡🤪 ${prefix}abraço @
 | ೈ፝͜͡🤪 ${prefix}mano @
 | ೈ፝͜͡🤪 ${prefix}matar @
 | ೈ፝͜͡🤪 ${prefix}socar @
 | ೈ፝͜͡🤪 ${prefix}chutar @
 | ೈ፝͜͡🤪 ${prefix}amor @
 | ೈ፝͜͡🤪 ${prefix}ódio @
 | ೈ፝͜͡🤪 ${prefix}casacomigo @
 | ೈ፝͜͡🤪 ${prefix}cancelar (cancela o pedido de casamento)
 | ೈ፝͜͡🤪 ${prefix}divorciar
 | ೈ፝͜͡🤪 ${prefix}gay
 | ೈ፝͜͡🤪 ${prefix}hétero
 | ೈ፝͜͡🤪 ${prefix}pocoto
 | ೈ፝͜͡🤪 ${prefix}feio
 | ೈ፝͜͡🤪 ${prefix}lindo
 | ೈ፝͜͡🤪 ${prefix}linda
 | ೈ፝͜͡🤪 ${prefix}rico
 | ೈ፝͜͡🤪 ${prefix}pobre
 | ೈ፝͜͡🤪 ${prefix}puta
 | ೈ፝͜͡🤪 ${prefix}corno
 | ೈ፝͜͡🤪 ${prefix}gado
 | ೈ፝͜͡🤪 ${prefix}vesgo
 | ೈ፝͜͡🤪 ${prefix}calvo
 | ೈ፝͜͡🤪 ${prefix}noia
 | ೈ፝͜͡🤪 ${prefix}sigma
 | ೈ፝͜͡🤪 ${prefix}beta
 | ೈ፝͜͡🤪 ${prefix}nazista
 | ೈ፝͜͡🤪 ${prefix}pau
 | ೈ፝͜͡🤪 ${prefix}bct
 | ೈ፝͜͡🤪 ${prefix}rankgay
 | ೈ፝͜͡🤪 ${prefix}rankhetero
 | ೈ፝͜͡🤪 ${prefix}rankpocoto
 | ೈ፝͜͡🤪 ${prefix}rankfeio
 | ೈ፝͜͡🤪 ${prefix}rankrico
 | ೈ፝͜͡🤪 ${prefix}rankpobre
 | ೈ፝͜͡🤪 ${prefix}rankputa
 | ೈ፝͜͡🤪 ${prefix}rankcorno
 | ೈ፝͜͡🤪 ${prefix}rankgado
 | ೈ፝͜͡🤪 ${prefix}rankvesgo
 | ೈ፝͜͡🤪 ${prefix}rankcalvo
 | ೈ፝͜͡🤪 ${prefix}ranknoia
 | ೈ፝͜͡🤪 ${prefix}ranksigma
 | ೈ፝͜͡🤪 ${prefix}rankbeta
 | ೈ፝͜͡🤪 ${prefix}ranknazista
 | ೈ፝͜͡🤪 ${prefix}rankpau
 | ೈ፝͜͡🤪 ${prefix}rankxrc
 | ೈ፝͜͡🤪 ${prefix}tinder ❤️‍🔥
 | ೈ፝͜͡🤪 ${prefix}casal
 | ೈ፝͜͡🤪 ${prefix}shipo @
 | ೈ፝͜͡🤪 ${prefix}golpe @
 | ೈ፝͜͡🤪 ${prefix}chance (diga algo)
 | ೈ፝͜͡🤪 ${prefix}sn (pergunte algo)
╰════════════════════╮`
}

exports.menuzoeira = menuzoeira