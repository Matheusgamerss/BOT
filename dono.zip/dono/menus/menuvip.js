const menuvip = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐕𝐈𝐏 』
╭════════════════════╯
 | ೈ፝͜͡🤑 ${prefix}gerarcpf
 | ೈ፝͜͡🤑 ${prefix}gerarnmr 
 | ೈ፝͜͡🤑 ${prefix}docfake 
 | ೈ፝͜͡🤑 ${prefix}recrutar (apenas ADM)
 | ೈ፝͜͡🤑 ${prefix}recrutar2 (apenas ADM)
 | ೈ፝͜͡🤑 ${prefix}ausente
 | ೈ፝͜͡🤑 ${prefix}ativo
 | ೈ፝͜͡🤑 ${prefix}delete
 | ೈ፝͜͡🤑 ${prefix}dam (apaga a sua msg tbm)
 | ೈ፝͜͡🤑 ${prefix}rgpf
 | ೈ፝͜͡🤑 ${prefix}rgaf
 | ೈ፝͜͡🤑 ${prefix}lerfoto
 | ೈ፝͜͡🤑 ${prefix}getpp
 | ೈ፝͜͡🤑 ${prefix}igstalk
 | ೈ፝͜͡🤑 ${prefix}mediafire
 | ೈ፝͜͡🤑 ${prefix}mediafire2
 | ೈ፝͜͡🤑 ${prefix}s2 (figu sem legenda)
 | ೈ፝͜͡🤑 ${prefix}gpt (Lucas, no PV)
 | ೈ፝͜͡🤑 ${prefix}Katy (no PV)
 | ೈ፝͜͡🤑 ${prefix}Jeff (no PV)
 | ೈ፝͜͡🤑 ${prefix}menu+18 (no PV)
╰════════════════════╮
『 𝐏𝐔𝐗𝐀𝐃𝐀𝐒 』
╭════════════════════╯
 | ೈ፝͜͡🤑 ${prefix}nome
 | ೈ፝͜͡🤑 ${prefix}nome2
 | ೈ፝͜͡🤑 ${prefix}nome3
 | ೈ፝͜͡🤑 ${prefix}nome4
 | ೈ፝͜͡🤑 ${prefix}tel
 | ೈ፝͜͡🤑 ${prefix}tel2
 | ೈ፝͜͡🤑 ${prefix}cpf
 | ೈ፝͜͡🤑 ${prefix}cpf2
 | ೈ፝͜͡🤑 ${prefix}placa
 | ೈ፝͜͡🤑 ${prefix}bin
 | ೈ፝͜͡🤑 ${prefix}cep
 | ೈ፝͜͡🤑 ${prefix}cnpj
 | ೈ፝͜͡🤑 ${prefix}score
 | ೈ፝͜͡🤑 ${prefix}email
 | ೈ፝͜͡🤑 ${prefix}rg
 | ೈ፝͜͡🤑 ${prefix}chassi
╰════════════════════╮`
}

exports.menuvip = menuvip