const menudown = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒 』
╭════════════════════╯
 | ೈ፝͜͡💿 ${prefix}play (nome ou link)
 | ೈ፝͜͡💿 ${prefix}play2 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}play3 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}play4 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}play5 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}spotify (nome da música)
 | ೈ፝͜͡💿 ${prefix}playlist (nome ou link)
 | ೈ፝͜͡💿 ${prefix}ytsearch (nome da música)
 | ೈ፝͜͡💿 ${prefix}ytmp4 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}ytmp3 (nome ou link)
 | ೈ፝͜͡💿 ${prefix}tiktok (envio de vídeo)
 | ೈ፝͜͡💿 ${prefix}tiktokhd (envio de vídeo em HD)
 | ೈ፝͜͡💿 ${prefix}tiktok2 (envio de áudio)
 | ೈ፝͜͡💿 ${prefix}tiktokimg (envio de imagem)
 | ೈ፝͜͡💿 ${prefix}instamp4 (link)
 | ೈ፝͜͡💿 ${prefix}instamp3 (link)
 | ೈ፝͜͡💿 ${prefix}facebook (link)
 | ೈ፝͜͡💿 ${prefix}facebook2 (link)
 | ೈ፝͜͡💿 ${prefix}twitter (link)
 | ೈ፝͜͡💿 ${prefix}pinterest (nome)
 | ೈ፝͜͡💿 ${prefix}letra (nome)
 | ೈ፝͜͡💿 ${prefix}imgpralink (marcar imagem)
 | ೈ፝͜͡💿 ${prefix}videopralink (marcar vídeo)
 | ೈ፝͜͡💿 ${prefix}viraraudio (marcar vídeo)
 | ೈ፝͜͡💿 ${prefix}chatgpt
 | ೈ፝͜͡💿 ${prefix}imagegpt
 | ೈ፝͜͡💿 ${prefix}cotação
╰════════════════════╮`
}

exports.menudown = menudown