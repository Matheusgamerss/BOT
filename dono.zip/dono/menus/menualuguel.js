const menualuguel = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✰𝐀𝐋𝐔𝐆𝐔𝐄𝐋 』
╭════════════════════╯
 | ೈ፝͜͡💰 ${prefix}me
 | ೈ፝͜͡💰 ${prefix}recarga 
 | ೈ፝͜͡💰 ${prefix}loja 
 | ೈ፝͜͡💰 ${prefix}storelist
 | ೈ፝͜͡💰 ${prefix}alugar
 | ೈ፝͜͡💰 ${prefix}buykeygp
 | ೈ፝͜͡💰 ${prefix}buyvip
 | ೈ፝͜͡💰 ${prefix}buyvipgp
 | ೈ፝͜͡💰 ${prefix}buycard
 | ೈ፝͜͡💰 ${prefix}reembolsar 
 | ೈ፝͜͡💰 ${prefix}transferirsaldo
╰════════════════════╮
『 𝐃𝐎𝐍𝐎 』
╭════════════════════╯
 | ೈ፝͜͡💰 ${prefix}addsaldo
 | ೈ፝͜͡💰 ${prefix}rmsaldo
 | ೈ፝͜͡💰 ${prefix}addrent
 | ೈ፝͜͡💰 ${prefix}tirarrent
 | ೈ፝͜͡💰 ${prefix}delrent
 | ೈ፝͜͡💰 ${prefix}listrent
 | ೈ፝͜͡💰 ${prefix}lastrent
╰════════════════════╮`
}

exports.menualuguel = menualuguel