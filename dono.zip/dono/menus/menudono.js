const menudono = (sender, prefix) => {
return `༒W̷E̷L̷C̷O̷M̷E̷༒
⇒ @${sender.split("@")[0]}

『 𝐌𝐄𝐍𝐔✮𝐃𝐎𝐍𝐎 』
╭════════════════════╯
 | ೈ፝͜͡🔱 ${prefix}bangp
 | ೈ፝͜͡🔱 ${prefix}unbangp
 | ೈ፝͜͡🔱 ${prefix}setpgp
 | ೈ፝͜͡🔱 ${prefix}setcofc
 | ೈ፝͜͡🔱 ${prefix}join (entrar no grupo)
 | ೈ፝͜͡🔱 ${prefix}sair (sair do grupo)
 | ೈ፝͜͡🔱 ${prefix}sairdogp
 | ೈ፝͜͡🔱 ${prefix}fotomenu
 | ೈ፝͜͡🔱 ${prefix}logomenu
 | ೈ፝͜͡🔱 ${prefix}fundomenu
 | ೈ፝͜͡🔱 ${prefix}fundoping
 | ೈ፝͜͡🔱 ${prefix}fotobot
 | ೈ፝͜͡🔱 ${prefix}nick-dono 
 | ೈ፝͜͡🔱 ${prefix}nome-bot 
 | ೈ፝͜͡🔱 ${prefix}clonar (marcar foto)
 | ೈ፝͜͡🔱 ${prefix}setprefix
 | ೈ፝͜͡🔱 ${prefix}addads
 | ೈ፝͜͡🔱 ${prefix}setads
 | ೈ፝͜͡🔱 ${prefix}addadsimg
 | ೈ፝͜͡🔱 ${prefix}rmads
 | ೈ፝͜͡🔱 ${prefix}listads
 | ೈ፝͜͡🔱 ${prefix}addmsg
 | ೈ፝͜͡🔱 ${prefix}rmmsg
 | ೈ፝͜͡🔱 ${prefix}listmsg
 | ೈ፝͜͡🔱 ${prefix}addrandom
 | ೈ፝͜͡🔱 ${prefix}envrandom
 | ೈ፝͜͡🔱 ${prefix}envglobal
 | ೈ፝͜͡🔱 ${prefix}delrandom
 | ೈ፝͜͡🔱 ${prefix}rmrandom
 | ೈ፝͜͡🔱 ${prefix}rmglobal
 | ೈ፝͜͡🔱 ${prefix}rgtm
 | ೈ፝͜͡🔱 ${prefix}deltm
 | ೈ፝͜͡🔱 ${prefix}tm (transmissão global)
 | ೈ፝͜͡🔱 ${prefix}nuke (arquivar grupo)
 | ೈ፝͜͡🔱 ${prefix}blockcmd
 | ೈ፝͜͡🔱 ${prefix}unblockcmd
 | ೈ፝͜͡🔱 ${prefix}listacomandos
 | ೈ፝͜͡🔱 ${prefix}block @
 | ೈ፝͜͡🔱 ${prefix}unblock @
 | ೈ፝͜͡🔱 ${prefix}blocklist
 | ೈ፝͜͡🔱 ${prefix}bcgp (TM no PV)
 | ೈ፝͜͡🔱 ${prefix}anticall 1/0 (call PV)
 | ೈ፝͜͡🔱 ${prefix}servip
 | ೈ፝͜͡🔱 ${prefix}addvip
 | ೈ፝͜͡🔱 ${prefix}delvip
 | ೈ፝͜͡🔱 ${prefix}addvipgp
 | ೈ፝͜͡🔱 ${prefix}delvipgp
 | ೈ፝͜͡🔱 ${prefix}idgp
 | ೈ፝͜͡🔱 ${prefix}listagp
 | ೈ፝͜͡🔱 ${prefix}linkdogp
 | ೈ፝͜͡🔱 ${prefix}iddogp
 | ೈ፝͜͡🔱 ${prefix}addrent
 | ೈ፝͜͡🔱 ${prefix}delrent
 | ೈ፝͜͡🔱 ${prefix}listrent
 | ೈ፝͜͡🔱 ${prefix}gerarkeygp
 | ೈ፝͜͡🔱 ${prefix}gerarkeyvip
 | ೈ፝͜͡🔱 ${prefix}gerarkeyvipgp
 | ೈ፝͜͡🔱 ${prefix}gerarkeycard
 | ೈ፝͜͡🔱 ${prefix}envmsg
 | ೈ፝͜͡🔱 ${prefix}msgpv
 | ೈ፝͜͡🔱 ${prefix}ausente
 | ೈ፝͜͡🔱 ${prefix}voltei
 | ೈ፝͜͡🔱 ${prefix}rmtinder
 | ೈ፝͜͡🔱 ${prefix}autobang
 | ೈ፝͜͡🔱 ${prefix}delautobang
 | ೈ፝͜͡🔱 ${prefix}globalblocklist
 | ೈ፝͜͡🔱 ${prefix}multiprefixo
 | ೈ፝͜͡🔱 ${prefix}addprefixo
 | ೈ፝͜͡🔱 ${prefix}delprefixo
 | ೈ፝͜͡🔱 ${prefix}prefixos
 | ೈ፝͜͡🔱 ${prefix}addxp
 | ೈ፝͜͡🔱 ${prefix}tirarxp
 | ೈ፝͜͡🔱 ${prefix}addlevel
 | ೈ፝͜͡🔱 ${prefix}tirarlevel
 | ೈ፝͜͡🔱 ${prefix}rmlevel
 | ೈ፝͜͡🔱 ${prefix}trfrlv
 | ೈ፝͜͡🔱 ${prefix}delcntd
 | ೈ፝͜͡🔱 ${prefix}trfrmsg
 | ೈ፝͜͡🔱 ${prefix}visualizarmsg
 | ೈ፝͜͡🔱 ${prefix}console
 | ೈ፝͜͡🔱 ${prefix}
 | ೈ፝͜͡🔱 ${prefix}configurar-bot
╰════════════════════╮`
}

exports.menudono = menudono