const infodono = (tempo, tempo_emoji, sender, NickDono, nmrdn, NomeDoBot, prefix) => {
return `
${tempo} ${tempo_emoji}
► @${sender.split("@")[0]}

╓─━⎓⎔⎓⎔⎓⎔⎓⎔⎓⎔⎓━─┒
┢╕\t\t🛡 𝑰𝑵𝑭𝑶𝑹𝑴𝑨𝑪̧𝑶̃𝑬𝑺 🛡
╽║
╽╟ • ɴɪᴄᴋ ᴅᴏɴᴏ: ${Matheus} 
╽║
╽╟ • ɴúᴍᴇʀᴏ: wa.me/${nmrdn.split("@")[0]} 559484391098
╽║
╽╟ • ɴᴏᴍᴇ ʙᴏᴛ: ${BLACK BOT V2}
╽║
╽╟ • ᴘʀᴇꜰɪxᴏ ~>〘 ${prefix} 〙!
┕╨⚋⚋⚋⚋⚋⚋⚋⚋⚋⚋⚋⚋⚋⚋┚

"𝑚𝑎𝑙𝑑𝑖𝑡𝑜 𝑜 ℎ𝑜𝑚𝑒𝑚 𝑞𝑢𝑒 𝑐𝑜𝑛𝑓𝑖𝑎 𝑛𝑜 ℎ𝑜𝑚𝑒𝑚" *~ Jeremias 17:5a* 👑

ꚠㅤ┋ㅤ@Matheus ヅ
`
};

exports.infodono = infodono;